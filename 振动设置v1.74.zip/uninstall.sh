#!/system/bin/sh

# 清除元模块残留
mtr="/data/adb/metamodule/mnt/VibratSet"
[ -d "$mtr" ] && rm -rf "$mtr"
# 清除MiuiExtra配套震动映射
sed -i "/string/d; s/true/false/g" \
/data/misc/*/prefs/moe.chenxy.miuiextra/*vibrat*.xml
