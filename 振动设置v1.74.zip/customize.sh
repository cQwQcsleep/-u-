SKIPUNZIP=0
if [ "$(which magisk)" ]; then
BM="Magisk:$MAGISK_VER│$MAGISK_VER_CODE"
elif [ "$KSU" ]; then
BM="KSU:$KSU_KERNEL_VER_CODE│$KSU_VER_CODE"
elif [ "$APATCH" ]; then
BM="APatch:$APATCH_VER│$APATCH_VER_CODE"; else
ui_print "‼ Magisk/KSU/APatch only ‼"; abort " "; fi
M="$MODPATH"; F="$M/File/wave"; lab="$M/File"
S="system"; sp="system.prop"; msp="$M/$sp"
dle="module.prop"; bin="*_rtp.bin"; ld="eca86b"
mde="$M/$dle"; dam="/data/adb/modules"
instdir="$dam/$MODID"; obui="/odm/etc/build.prop"
vbui="/vendor/build.prop"; ev="/vendor/etc/vibrator"
of="/odm/firmware"; vf="/vendor/firmware"
aw="aw8697_haptic*.bin"; efe="effect_[0-9]*.bin"
sbui="/$S/build.prop"; pbui="/product/etc/build.prop"
sebui="/${S}_ext/etc/build.prop"
uson=$(cat $mde | grep '^updateJson=' | cut -d = -f2)
AUT=$(cat $mde | grep '^author=' | cut -d = -f2)
mv -f $msp $M/F; unzip -o $M/F -d $M/ > /dev/null 2>&1
if [ -s $lab/sp1* ]; then . $F/op*; else
echo ; echo "‼ 文件损坏 ‼"; abort ; fi
