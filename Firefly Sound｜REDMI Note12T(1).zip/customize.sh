set_permissions() {
    set_perm_recursive $MODPATH 0 0 0755 0644
    set_perm_recursive $MODPATH/system/vendor/etc 0 0 0755 0644 u:object_r:vendor_configs_file:s0
    set_perm_recursive $MODPATH/system/vendor/etc/audio 0 0 0755 0644 u:object_r:vendor_configs_file:s0
    set_perm_recursive $MODPATH/system/vendor/etc/dolby 0 0 0755 0644 u:object_r:vendor_configs_file:s0
}
ui_print "- 求关注窝酷安˃ʍ˂：别看啦没有脑婆"
ui_print "- 请选择是否跳转我的酷安主页"
ui_print "  音量+ ：选择跳转❤️"
ui_print "  音量- ：取消跳转💔"
ui_print "*********************************************"

# 检测用户的按键操作
choice=$(getevent -lc 1 2>/dev/null | grep "KEY_VOLUME" | awk '{print $3}' | tail -n 1)

case $choice in
    "KEY_VOLUMEUP")
        # 用户选择了音量+
        ui_print "- 你选择跳转LP的酷安主页"
        ui_print "- 正在跳转酷安主页..."
        am start -a android.intent.action.VIEW -d "coolmarket://www.coolapk.com/u/33227390"
        ui_print "- 感谢您的关注❤️您的支持是LP更新的最大动力QAQ"
        ;;
    "KEY_VOLUMEDOWN")
        # 用户选择了音量-
        ui_print "- 您选择了不跳转，但喜欢您会喜欢LP的感谢支持⊙︿⊙"
        ;;
    *)
        # 其他情况
        ui_print "- 未检测到有效输入，操作已取消"
        ;;
esac

rm -rf /data/dalvik-cache/*
rm -rf /data/system/package_cache/*
set_permissions
ui_print "- 清理缓存"