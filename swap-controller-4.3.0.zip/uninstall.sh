#!/system/bin/sh
# 卸载清理，但不保证所有参数都会重置

rm -rf /data/swapfile*
rm -f /data/swap_config.conf
rm -f /data/writeback
rm -f /cache/cgroup_opt.log
rm -f /cache/lmkd_opt.log

uninstall_module(){
  sleep 10
  if [ -e /my_stock ] || [ -e /my_product ]; then
    rom_update_db=/data/user_de/0/com.oplus.romupdate/databases/rom_update.db
    rm -f $rom_update_db
    if [ -f $rom_update_db.bak ]; then
      mv $rom_update_db.bak $rom_update_db
      sleep 1 && sync
    fi
    am force-stop com.oplus.romupdate
    am force-stop com.oplus.athena
  fi

  # oplus preload mode
  settings delete system disable_preload_mode

  device_config list activity_manager | while read row; do
  device_config delete activity_manager "$(echo $row | cut -d '=' -f1)"
  done

  pm enable com.android.htmlviewer/com.android.settings.services.MemoryOptimizationService 2>/dev/null
}

wait_until_login(){
  while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
  done
  until [ -d "/data/data/android" ]; do
    sleep 1
  done
}

if [ "$1" = "wait" ]; then
  uninstall_module
else
  {
    wait_until_login
    uninstall_module
  } &
fi