# 变量命名说明
# 小写+下划线 是局部变量
# 大写开头的是全局变量
# 全大写的是常量

readonly PEF_CONFIG_STORE="/system/vendor/etc/perf/perfconfigstore.xml"
readonly SWAP_CONFIG="/data/swap_config.conf"

source $MODPATH/scripts/tools.sh
source $MODPATH/scripts/tools.install.sh
source $MODPATH/scripts/tools.daemon.sh
source $MODPATH/scripts/tools.nandswap.sh
source $MODPATH/scripts/tools.romupdate.sh

INSTALLED_VERSION=$(getprop vtools.swap.module)
if [[ $INSTALLED_VERSION != '' && $INSTALLED_VERSION -lt 4101 ]]; then
  echo '请先卸载旧版并重启手机'
  echo 'Please uninstall the old version first and restart your phone'
  if [[ -d $MODPATH ]] && [[ $MODPATH = *scene_swap_controller* ]]; then
    echo '' > $MODPATH/remove
  fi
  exit 1
elif [[ $INSTALLED_VERSION != '' && $INSTALLED_VERSION -lt 4200 && -f $SWAP_CONFIG ]]; then
  echo '检测到旧版模块，自动丢弃原有的配置'
  rm -f $SWAP_CONFIG
fi

set_perm_recursive $MODPATH 0 0 0755 0644

Swappiness=100
SwapEnable=false
SwapSize=2047
SwapUseLoop=false
ZramEnable=true
ZramSize=2047
Algorithm=lz4
ExtraFreeKBytes=25600
SwapPriority=-2
ZramWriteback=default
if nandswap_supported || smartswap_supported; then
  ZramWriteback=true
fi

ShadowFile=""
copy_to_module(){
  src_file="$1"
  if [[ -f "$src_file" ]]; then
    mkdir -p $(dirname "$MODPATH$src_file")
    ShadowFile="$MODPATH$src_file"
    cp -f "$src_file" "$ShadowFile"
    return_true
  fi
  return_false
}

# update_overlay ro.lmk.enhance_batch_kill false
update_overlay() {
  prop="$1"
  value="$2"
  sed -i "s/Name=\"$prop\"[ ]*Value=\".*\"/Name=\"$prop\" Value=\"$value\"/ig" "$ShadowFile"
}

# 适用于修改<item name="xxx" type="xxx" value="xxx"格式的数据
# update_item trimSwitch bool false 
update_item() {
  name="$1"
  type="$2"
  value="$3"
  sed -i "s/<item name=\"$name\"[ ]*type=\".*\"[ ]*value=\".*\"/<item name=\"$name\" type=\"$type\" value=\"$value\"/g" $ShadowFile
}
# read_config key default_value
read_config() {
  value=$(cat $SWAP_CONFIG | grep "^$1=" | cut -f2 -d '=')
  if [[ "$value" == "" ]]; then
    echo $2
  else
    echo "$value"
  fi
}

# 解析旧版模块创建的配置（读取以便保留部分用户自定义配置）
restore_config() {
  if [[ -f $SWAP_CONFIG ]]; then
    SwapEnable=$(read_config swap $SwapEnable)
    SwapSize=$(read_config swap_size $SwapSize)
    SwapUseLoop=$(read_config swap_use_loop $SwapUseLoop)
    ZramEnable=$(read_config zram $ZramEnable)
    ZramSize=$(read_config zram_size $ZramSize)
    ZramWriteback=$(read_config zram_writeback $ZramWriteback)
    echo "- ZRAM(Customized): ${ZramSize}MB"
    if [[ "$SwapEnable" == 'true' ]]; then
      echo "- SWAP(Customized): ${SwapSize}MB"
    else
      echo "- SWAP(customized): OFF"
    fi
  fi

  total=$ZramSize
  if $SwapEnable && [[ $SwapSize -gt 0 ]]; then
    total=$((total + SwapSize))
  fi
  if [[ $total -gt 8000 ]]; then
    ExtraFreeKBytes=131072 # 128MB
  elif [[ $total -gt 6000 ]]; then
    ExtraFreeKBytes=98304 # 96MB
  elif [[ $total -gt 4500 ]]; then
    ExtraFreeKBytes=65536 # 64MB
  elif [[ $total -gt 2000 ]]; then
    ExtraFreeKBytes=32768 # 32MB
  fi
}

# 根据设备性能自动调整参数
auto_config () {
  echo "- RAM Total:${MEM_TOTAL_KB/1024}MB (${MEM_TOTAL_GB} GB?)"

  # Linux Kernel > 6.6
  if [[ $(kernel_compare "6.6") -ge 0 ]]; then
    Swappiness=125
  elif [[ $(get_swappiness_max) -gt 100 ]]; then
    Swappiness=150
  fi

  # 优先zstd 如果支持
  for alg in zstd zstdn lz4k lz4 lzo-rle lzo; do
    if [[ "$(grep $alg /sys/block/zram0/comp_algorithm)" != '' ]]; then
      Algorithm=$alg
      break
    fi
  done

  no_swap=false
  # 如果支持NandSwap/SmartSwap
  if nandswap_supported || smartswap_supported; then
    echo "- NandSwap/SmartSwap: Supported"
    if [[ $(kernel_compare "5.1") -gt 0 ]]; then
      # 性能还不错的新机 直接1:1
      ZramSize=$((MEM_TOTAL_GB * 1024))
    else
      # 老登 设为RAM的80%
      ZramSize=$((MEM_TOTAL_GB * 1024 * 7 / 10))
    fi
    no_swap=true

  # 如果已开启拓展内存直接1:1
  elif extm_supported && extm_enabled; then
    echo "- Extended MEM: Supported"
    ZramSize=$((MEM_TOTAL_GB * 1024))
    no_swap=true

  # 或者内存够大，并且内核够新，直接1:1
  elif [[ $MEM_TOTAL_GB -gt 8 && $(kernel_compare "6.6") -ge 0 ]]; then
    ZramSize=$((MEM_TOTAL_GB * 1024))

  # 新手机性能比较好，zram 压得更轻松，加大点
  elif [[ $(kernel_compare "6.6") -ge 0 ]]; then
    ZramSize=$((MEM_TOTAL_GB * 1024 * 8 / 10))

  # 支持zstd算法，设为RAM的70%
  elif [[ "$Algorithm" == zstd* ]]; then
    ZramSize=$((MEM_TOTAL_GB * 1024 * 7 / 10))

  # 啥也不支持，ZRAM大小默认为RAM的1/2，相对保守
  else
    ZramSize=$((MEM_TOTAL_GB * 1024 / 2))
  fi

  SwapSize=$((MEM_TOTAL_GB * 1024 - ZramSize))
  swap_max=$((MEM_TOTAL_GB * 1024 / 3))
  if ! $no_swap && hp_soc && ufs_health_ok; then
    SwapEnable=true
    # ColorOS 14/15(OnePlus11|OnePlus12)
    if ! extm_supported && [[ -d /sys/block/zram1 && -f $BLK_OPLUS ]]; then
      ZramSize=0
      # SwapSize=$((MEM_TOTAL_GB * 1024 / 3))
      zram1_size=$(cat /sys/block/zram1/disksize)
      zram1_size=$((zram1_size/1024/1024))
      SwapSize=$((MEM_TOTAL_GB * 1024 - zram1_size))
      swap_max=$((MEM_TOTAL_GB * 1024 / 2))
    elif [ -e $BLK_OPLUS_CRYPTO ]; then
      if [ $MEM_TOTAL_GB -le 8 ]; then
        SwapSize=0
      else
        SwapSize=$((SwapSize-1024))
      fi
    # ZRAM容量足够 关闭swapfile
    elif [[ "$ZramSize" -gt 9999 ]]; then
      SwapEnable=false
    fi
  else
    SwapEnable=false
  fi
  SwapSize=$(min $swap_max $SwapSize)
  SwapSize=$(max 0 $SwapSize)
  if [[ "$SwapSize" -lt 128 ]]; then
    SwapEnable=false
  fi

  echo "- ZRAM(Recommended): ${ZramSize}MB"
  if $SwapEnable ; then
    echo "- SWAP(Recommended): ${SwapSize}MB"
  else
    echo "- SWAP(Recommended): OFF"
  fi
}

# 自动配置
auto_config
# 读取已经存在的配置
restore_config

if writeback_supported; then
zram_writeback_config="
# ZRAM Writeback
# default 保持系统默认配置
# true 开启ZRAM Writeback，并由模块配置回写设备
# false 关闭ZRAM Writeback
zram_writeback=$ZramWriteback

"
elif nandswap_supported || smartswap_supported; then
disable_nandswap
disable_smartswap
if [[ "$ZramWriteback" == 'default' ]]; then
  ZramWriteback='true'
fi
zram_writeback_config="
# NandSwap/Smartswap
# true 启用，由模块配置回写设备(需要关闭系统的拓展内存)
# false 禁用
zram_writeback=$ZramWriteback

"
fi

daemon_service=$(read_config daemon_service basic)
daemon_config=$(get_daemon_config "$daemon_service")


  echo "
# 是否配置swapfile
swap=$SwapEnable

# swapfile大小(MB)，部分设备超过2047会开启失败
# 注意，修改swap大小，需要手动删除/data/swapfile，才会重新创建
swap_size=$SwapSize

# swapfile使用顺序
#  0 与zram同时使用
# -2 用完zram后再使用
#  5 优先于zram使用
swap_priority=$SwapPriority

# 是否将swapfile挂载为回环设备
# 在很多设备上性能表现很差。如非必要，不建议开启
swap_use_loop=$SwapUseLoop

# 是否配置zram
# 注意: 设为false并不代表禁用zram，而是保持系统默认配置
# 如果你想关闭系统默认开启的zram，则应设为true，并配置zram_size为0
zram=$ZramEnable

# zram大小(MB)，部分设备超过2047会开启失败
zram_size=$ZramSize

# zram压缩算法(可设置的值取决于内核支持)
# zstd lz4 lzo lzo-rle性能都很好
comp_algorithm=$Algorithm

$zram_writeback_config
# 使用SWAP的积极性，0 ~ $(get_swappiness_max)
swappiness=$Swappiness

# 额外空余内存(kbytes)
# 数值越大越容易触发swap和内存回收
extra_free_kbytes=$ExtraFreeKBytes

# 水位线调整(1到1000，越大内存回收越积极)
# 例如设为1000，则表示10%，表示内存水位线low-min-high之间，各相差RamSize * 10%
# 剩余内存低于low的值开始回收内存，直到内存不低于high的值
watermark_scale_factor=50

$daemon_config" > $SWAP_CONFIG

# Xiaomi'8GEN1
if [[ "$SOC" == "SM8450" ]] && [[ "$(getprop ro.miui.ui.version.name)" != '' ]]; then
  echo '- [Xiaomi] 8GEN1'
  update_prop ro.lmk.use_minfree_levels false
  update_prop ro.lmk.use_psi true # OS1和MIUi可以两个false解决杀后台，但OS2上会导致LMKD爆炸
  update_prop ro.lmk.psi_partial_stall_ms 500 # 只能改点别的参数凑合一下了
  update_prop ro.lmk.psi_complete_stall_ms 999
  update_prop ro.lmk.medium 1001
  update_prop ro.lmk.critical 900

# MTK 新系统(Android 10+)用PSI，效果更好
elif [[ "$SDK_VERSION" -gt 28 ]] && [[ $(echo "$PLATFORM" | grep -e '^mt') != '' ]]; then
  echo '- [Mediatek] Use PSI'
  update_prop ro.lmk.use_minfree_levels false
  update_prop ro.lmk.use_psi true

# 非MTK 新系统(Android 11+)用PSI，效果更好
elif [[ "$SDK_VERSION" -gt 29 ]]; then
  echo '- [Android 11+] Use PSI'
  update_prop ro.lmk.use_minfree_levels false
  update_prop ro.lmk.use_psi true

# 喜欢杀后台的特殊机型，特殊对待
elif [[ "$PLATFORM" == "kona" ]] ; then
  echo '- [Qualcomm] KONA Use LMK'
  update_prop ro.lmk.medium 1001
  # 方式1 使用传统LMK
  update_prop ro.lmk.use_minfree_levels true
  update_prop ro.lmk.use_psi false
  # 方式2 降低PSI报告积极性
  # update_prop ro.lmk.psi_partial_stall_ms 350
fi

# OPPO
if find /proc -maxdepth 1 -name "oplus*" | grep -q .; then
  cat $MODPATH/system.oplus.prop >> $MODPATH/system.prop
  if [ "$(pm list packages -e com.oplus.romupdate)" = '' ]; then
    echo '警告：！！！'
    echo '更新服务(com.oplus.romupdate)已被冻结'
    echo '请解冻或找回该应用，再重新安装模块，否则部分修改可能不生效！'
  fi
# XIAOMI
elif [[ $(getprop ro.miui.ui.version.name) != '' ]]; then
  cat $MODPATH/system.mi.prop >> $MODPATH/system.prop
  pm disable com.android.htmlviewer/com.android.settings.services.MemoryOptimizationService 2>/dev/null
fi
# Qualcomm
if [ -e /sys/class/kgsl ]; then
  cat $MODPATH/system.qti.prop >> $MODPATH/system.prop
fi
rm $MODPATH/system.oplus.prop
rm $MODPATH/system.mi.prop
rm $MODPATH/system.qti.prop

if [[ -f $PEF_CONFIG_STORE && -s $PEF_CONFIG_STORE ]]; then
  echo '- Patch perfconfigstore.xml' # Qualcomm
  copy_to_module $PEF_CONFIG_STORE

  update_overlay ro.vendor.perf.enable.prekill false
  update_overlay ro.lmk.kill_heaviest_task_dup false
  update_overlay ro.lmk.enhance_batch_kill false
  update_overlay ro.lmk.enable_watermark_check true
  update_overlay ro.lmk.enable_preferred_apps false
  # update_overlay ro.lmk.thrashing_threshold 20 # default 10
  # update_overlay ro.lmk.thrashing_limit_pct_dup 100

  # 喜欢杀后台的特殊机型，特殊对待
  if [[ "$PLATFORM" == "kona" ]] ; then
    update_overlay ro.lmk.super_critical 900
  else
    update_overlay ro.lmk.super_critical 800
  fi
  update_overlay ro.lmk.direct_reclaim_pressure 0
  update_overlay ro.lmk.reclaim_scan_threshold 0

  update_overlay ro.vendor.qti.sys.fw.bg_apps_limit 32768

  update_overlay vendor.debug.enable.memperfd false
  update_overlay vendor.appcompact.enable_app_compact false

  update_overlay ro.lmk.nstrat_low_swap 1
  update_overlay ro.lmk.nstrat_psi_partial_ms 250 # default 70
  update_overlay ro.lmk.nstrat_psi_complete_ms 700 # default 70
  update_overlay ro.lmk.psi_scrit_complete_stall_ms 800 # default 400
  update_overlay ro.lmk.nstrat_psi_scrit_complete_stall_ms 800
  update_overlay ro.lmk.nstrat_wmark_boost_factor 0 # default 1 可能导致连续启动多个应用时杀死大量进程

  update_overlay ro.vendor.perf.enable.prekill false
  update_overlay vendor.prekill_MIN_ADJ_to_Kill 906 # default 800
  update_overlay vendor.prekill_MAX_ADJ_to_Kill 1001 # default 1000
  update_overlay vendor.debug.enable.memperfd false
  update_overlay vendor.enable.memperfd_MIN_RAM_in_KB 393216 # default 1048576 
  # update_overlay vendor.enable.memperfd_MAX_RAM_in_KB 15728640 # default 15728640
  update_overlay ro.lmk.cache_percent 5 # default 10

  update_overlay vendor.perf.phr.enable false
  update_overlay vendor.perf.phr.hr_min_rate_high 2.0
  # update_overlay o.vendor.qti.sys.fw.use_trim_settings false # default true
  update_overlay ro.vendor.qti.sys.fw.empty_app_percent 145 # default 50
  update_overlay ro.vendor.qti.sys.fw.trim_empty_percent 170 # default 100
  update_overlay ro.vendor.qti.sys.fw.trim_cache_percent 170 # default 100
  update_overlay ro.vendor.qti.sys.fw.trim_enable_memory 16777216 # default 4294967296
fi

if [[ -d /my_stock ]] || [[ -d /my_product ]]; then
  prjname=$(getprop ro.boot.prjname)
  manufacturer=$(getprop ro.product.odm.manufacturer)
  for my in /my_stock /my_product; do
    oplus_ext=$my/etc/extension
    if [[ -d $oplus_ext ]]; then
      if copy_to_module $oplus_ext/sys_osense_memory_config.xml; then
        update_item trimSwitch bool false
        update_item thermal int 46
        update_item trimNum int 0
        update_item resSwitch bool false
        update_item switch bool false
        update_item maxShrinBytes long 819200
        update_item maxSwapOutBytes long 409600
        update_item releaseAvailMemThreshold string '2|500-3|500-4|750-6|1000-8|1500-12|2000-16|2500-24|3000'
        update_item releaseMinBgCount string '2|2-3|3-4|4-6|6-8|8-12|12-16|18-24|25'
        sed -i '/<config name="dynaZramConfig"/,/<item name="switch"/ s/value="true"/value="false"/' $ShadowFile
      fi
      # oneplus /my_product/etc/extension/sys_osense_feature_common_config.xml
      # realme gt neo7se /my_product/etc/extension/sys_custom_osense_feature_common_config.xml
      # realme gt neo5 /my_product/etc/extension/sys_osense_common_config.xml
      for common_config in sys_osense_feature_common_config.xml sys_osense_common_config.xml sys_custom_osense_feature_common_config.xml; do
        if copy_to_module $oplus_ext/$common_config; then
          update_item POLICY_CLEAN bool false
          update_item POLICY_PRELOAD bool false
          # update_item tuningSwitch bool false
          # update_item featureSwitch bool false
          update_item cpuLimitKillSwitch bool false
          update_item EnableIdleDynamicSwappiness bool false
          update_item HighloadSwappiness int $Swappiness
          update_item EnableHighloadSwappiness bool false
          update_item BalancedSwappiness int $Swappiness
          update_item HighLoadMinCachedMap string "6-500|8-900|12-1400|16-1700|24-2000"
          # update_item AllowCompressOnBigCore bool false
          # sed -i '/<config name="osenseCompressConfig"/,/<item name="Enable"/ s/value="true"/value="false"/' $ShadowFile
        fi
      done
      # oneplus /my_product/etc/extension/sys_memory_nirvana_config.xml
      # realme gt7 pro /my_product/etc/extension/sys_custom_memory_nirvana_config.xml
      for nirvana_config in sys_memory_nirvana_config.xml sys_custom_memory_nirvana_config.xml; do
        if copy_to_module $oplus_ext/$nirvana_config; then
          update_item EnableNoSwap bool false
          update_item EnableLightNoSwap bool false
          update_item NirvanaSupportMinRam int 32
          update_item LightNoSwapSupportMinRam int 32
          update_item HighTempThreshold int 46
          update_item ThermalEnterThres int 46000
          update_item ThermalExitThres int 44000
          update_item ExpectedBgCountMap string "6-99|8-99|12-99|16-99|24-99"
          update_item CamExpectedBgCount string "6-50|8-50|12-50|16-50|24-50"
          update_item ClearMinInterval long 5000
          update_item thermal_level_42000 string "8-99|12-99|16-99|24-99"
          update_item thermal_level_51000 string "8-50|12-50|16-50|24-50"
          update_item NoSwapLow string "6-80000|8-100000|12-150000|16-200000|24-300000"
          update_item NoSwapHigh string "6-80000|8-120000|12-200000|16-250000|24-350000"
          update_item NoSwapMax string "6-80000|8-1500000|12-250000|16-300000|24-400000"
          update_item FileCacheThresMap string "8-800000|12-1000000|16-1000000|24-2000000"
          update_item CamFileCacheThresMap string "8-1500000|12-1500000|16-2500000|24-3000000"
          # OnePlus 12 /my_product/etc/extension/sys_custom_memory_nirvana_config.xml
          update_item ThermalKillTempThreshold int 46000
        fi
      done
      # realme gt neo /my_product/etc/extension/feature_com.oplus.athena.xml 和 realme_product_rom_extend_feature_21609.xml
      if copy_to_module "$oplus_ext/${manufacturer}_product_rom_extend_feature_$prjname.xml" || copy_to_module "$oplus_ext/feature_com.oplus.athena.xml"; then
        if [[ "$(grep athena.ams.max.cached.processes $ShadowFile)" != '' ]]; then
          # 将name="athena.ams.max.cached.processes" args="*" 替换 为 name="athena.ams.max.cached.processes" args="String:16|255-12|255-8|255-6|255"
          sed -i '/<item name="athena.ams.max.cached.processes"/ s/args=".*"/args="String:16|255-12|255-8|255-6|255"/' $ShadowFile
          # realme ui 4.0
          sed -i '/<app_feature name="athena.ams.max.cached.processes"/ s/args=".*"/args="String:12|255-8|255"/' $ShadowFile
        else
          rm -f $ShadowFile
        fi
      fi

      # if copy_to_module "$oplus_ext/com.oplus.oplus-feature.xml"; then
      #   # 删除带  name="oplus.software.vip_preload" 的行
      #   sed -i '/<oplus-feature name="oplus.software.vip_preload"/d' $ShadowFile
      #   sed -i '/<oplus-feature name="oplus.software.parallel_preload"/d' $ShadowFile
      #   sed -i '/<oplus-feature name="oplus.software.next_preload"/d' $ShadowFile
      #   sed -i '/<oplus-feature name="oplus.software.sau_preload"/d' $ShadowFile
      #   sed -i '/<oplus-feature name="oplus.software.preload"/d' $ShadowFile
      #   sed -i '/<oplus-feature name="oplus.software.activity_preload"/d' $ShadowFile
      #   sed -i '/<oplus-feature name="oplus.software.preload_app_restore"/d' $ShadowFile
      #   sed -i '/<oplus-feature name="oplus.software.touch_preload"/d' $ShadowFile
      #   sed -i '/<oplus-feature name="oplus.software.top.preload"/d' $ShadowFile
      #   sed -i '/<oplus-feature name="oplus.software.osense.compress.enable"/d' $ShadowFile
      #   sed -i '/<oplus-feature name="oplus.software.memory_nirvana.enable"/d' $ShadowFile
      #   sed -i '/<oplus-feature name="oplus.software.oguard.enable"/d' $ShadowFile
      #   sed -i '/<oplus-feature name="oplus.software.qb_bg_clean.enable"/d' $ShadowFile
      # fi
    elif [[ ! -d $my && $MODPATH != '' ]]; then
      rm -rf $MODPATH$my
    fi
  done

  for f in sys_athena_custom_config_list sys_custom_clear_config; do
    cp -f $MODPATH/athena/$f.xml $MODPATH/my_product/etc/extension/$f.xml
  done

  readonly oplus_ext_0="$MODPATH/my_stock/etc/extension/sys_osense_appmng_decisionmaker_config.xml"
  readonly oplus_ext_1="/my_product/etc/extension/sys_custom_osense_appmng_decisionmaker_config.xml"
  if [[ -f $oplus_ext_1 ]]; then
    cp $oplus_ext_0 $MODPATH/$oplus_ext_1
    sed -i "s/<filter-name>.*<\/filter-name>/<filter-name>$name<\/filter-name>/ig" $MODPATH/$oplus_ext_1
  fi

  if [[ "$(getprop persist.sys.oplus.osense.version)" == 1* ]]; then
    cp -f $MODPATH/osense/v1/* $MODPATH/my_product/etc/extension/
  else
    cp -f $MODPATH/osense/v3/sys_osense_memory_decisionmaker_config.xml $MODPATH/my_stock/etc/extension/
  fi

  patch_update_list
  if [[ "$MODPATH" != '' && "$MODPATH" != '/' ]]; then
    rm -rf $MODPATH/athena
    rm -rf $MODPATH/osense
  fi
  settings put system disable_preload_mode 1
elif [[ "$MODPATH" != '' && "$MODPATH" != '/' ]]; then
  rm -rf $MODPATH/my_stock
  rm -rf $MODPATH/my_product
  rm -rf $MODPATH/athena
  rm -rf $MODPATH/osense
fi


set_perm_recursive $MODPATH/my_product 0 0 0755 0644 u:object_r:system_file:s0
set_perm_recursive $MODPATH/my_stock 0 0 0755 0644 u:object_r:system_file:s0


echo " 配置参数位于 $SWAP_CONFIG 可自行修改 "
echo " 或搭配Scene9.2.0及以后的版本"
echo " 可直接在SWAP设置里调节模块配置"
echo " "
echo " "


if [ -f "$MODPATH/scripts/tool.log.sh" ]; then
  echo '当前版本为调试版，将自动抓取lmkd、osense、athena、activity manager相关日志'
  echo '保存到 /sdcard/kill.log'
  echo " "
  echo " "
fi
