export MODPATH=${0%/*}

VERSION=$(grep '^versionCode=' $MODPATH/module.prop | cut -f2 -d '=')
setprop vtools.swap.module "$VERSION"

readonly LOG=/cache/lmkd_opt.log
# 清空日志
echo -n '' > $LOG

readonly LOG2=/cache/cgroup_opt.log
# 清空日志
echo -n '' > $LOG2

# 应用配置
sh $MODPATH/scripts/startup.sh >> $LOG 2>&1

echo "" >> $LOG
echo "全部完成！" >> $LOG

# 应用配置
if [ -f $MODPATH/scripts/service.dex ]; then
  echo "# extra.sh" >> $LOG2
  sh $MODPATH/scripts/extra.sh >> $LOG2 2>&1
fi

echo "" >> $LOG2
echo "全部完成！" >> $LOG2


# 开机后trim一下，有助于尽量保持写入速度
busybox=/data/adb/magisk/busybox
if [[ -f /data/adb/ksu/bin/busybox ]]; then
  busybox=/data/adb/ksu/bin/busybox
fi
if [[ -f $busybox ]]; then
  sm fstrim 2>/dev/null
  $busybox fstrim /data 2>/dev/null
  $busybox fstrim /cache 2>/dev/null
  $busybox fstrim /system 2>/dev/null
  sm fstrim 2>/dev/null
fi
