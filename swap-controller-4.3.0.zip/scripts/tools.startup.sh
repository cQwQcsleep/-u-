import_config(){
  readonly SWAP_CONFIG="/data/swap_config.conf"
  if [[ -f $SWAP_CONFIG ]]; then
    dos2unix $SWAP_CONFIG 2>/dev/null
    source $SWAP_CONFIG
  else
    echo "没有找到配置文件 $SWAP_CONFIG"
  fi
}

init_group() {
  g=/dev/memcg/$1
  if [[ ! -d "$g" ]]; then
    mkdir -p "$g"
  fi
  echo $2 > "$g/memory.swappiness"
  echo 1 > "$g/memory.use_hierarchy"
  if [[ $2 -le 30 ]]; then
    set_value 0 "$g/memory.anno_writeback_enable"
  else
    set_value 1 "$g/memory.anno_writeback_enable"
  fi
  echo 1 > "$g/memory.move_charge_at_immigrate"
  echo 1 > $g/memory.oom_control
}
