if [[ -f /sys/fs/cgroup/memory/memory.swappiness ]]; then
  readonly SCENE_MEMCG="/sys/fs/cgroup/memory"
elif [[ -f /dev/memcg/memory.swappiness ]]; then
  readonly SCENE_MEMCG="/dev/memcg"
fi

check_daemon_supported(){
  top_app="/dev/cpuset/top-app/cgroup.procs"
  bg_app="/dev/cpuset/background/cgroup.procs"
  fg_app="/dev/cpuset/foreground/cgroup.procs"

  # daemon文件不见了，不支持daemon_service
  if [[ ! -f $MODPATH/scripts/service.dex ]]; then
    echo NotSupported

  # 不支持cpuset，daemon_service无法工作
  elif [[ ! -f $top_app ]] || [[ ! -f $bg_app ]]; then
    echo NotSupported

  # 基于memcg的内存回收和增强服务冲突，降低评级
  elif [[ -f /dev/memcg/memory.force_swapout || -f /dev/memcg/memory.force_reclaim_zram ]]; then
    echo Level3

  elif [[ -f $fg_app ]] && [[ "$SDK_VERSION" -gt 27 ]] && [[ "$SDK_VERSION" -lt 34 ]]; then
    if [[ "$SCENE_MEMCG" != '' ]]; then
      [[ -e /proc/1/reclaim && $MEM_TOTAL_GB -gt 4 ]] && echo Level0 || echo Level1
    else
      echo Level2
    fi
  else
    echo Level3
  fi
}

get_daemon_config(){
  policy=$1
  supported=$(check_daemon_supported)

  # daemon_service
  # 由模块提供的增强服务，补充内存管理，具体表现为：
  # 阻止SWAP前台应用/重要进程占用的内存，并为后台应用设置内存限额
  # 使SWAP尽量发生在后台进程上，或能缓解使用SWAP导致的系统性能下滑
  # off     禁用
  # kill    启用 仅在内存严重不足时杀死一些进程
  # basic   启用 自动为进程设置分组，在内存严重不足时杀死一些进程
  # lazy    启用 限制后台应用内存用量，在内存严重不足时杀死一些进程
  # active  启用 严格限制后台应用内存用量，在内存严重不足时杀死一些进程

  # 是否支 daemon_service
  if [[ "$supported" == "Level0" ]]; then
  echo "# 由模块提供的增强服务，补充内存管理
# off     禁用
# kill    启用 仅在内存严重不足时杀死一些进程
# basic   启用 自动为进程设置分组，在内存严重不足时杀死一些进程
# lazy    启用 限制后台应用内存用量，在内存严重不足时杀死一些进程
# active  启用 严格限制后台应用内存用量，在内存严重不足时杀死一些进程
daemon_service=$policy
# 由daemon管理的内存使用率上限
daemon_used_limit=175%

"
  elif [[ "$supported" == "Level1" ]]; then
  echo "# 由模块提供的增强服务，补充内存管理
# off     禁用
# kill    启用 仅在内存严重不足时杀死一些进程
# basic   启用 自动为进程设置分组，在内存严重不足时杀死一些进程
# lazy    启用 限制后台应用内存用量，在内存严重不足时杀死一些进程
daemon_service=$policy
# 由daemon管理的内存使用率上限
daemon_used_limit=175%

"
  elif [[ "$supported" == "Level2" ]]; then
  echo "# 由模块提供的增强服务，补充内存管理
# off     禁用 禁用此功能特性
# kill    启用 仅在内存严重不足时杀死一些进程
# basic   启用 自动为进程设置分组，在内存严重不足时杀死一些进程
daemon_service=$policy
# 由daemon管理的内存使用率上限
daemon_used_limit=175%

"
  elif [[ "$supported" == "Level3" ]]; then
    if [[ "$policy" != kill && "$policy" != off ]]; then
      policy='kill'
    fi
  echo "# 由模块提供的增强服务，补充内存管理
# off     禁用 禁用此功能特性
# kill    启用 仅在内存严重不足时杀死一些进程
daemon_service=$policy
# 由daemon管理的内存使用率上限
daemon_used_limit=175%

"
  fi
}