if [[ -f /system/bin/losetup ]]; then
	alias losetup='/system/bin/losetup'
fi

# ColorOS(Nandswap) 和 Flyme(SmartSwap) 基本是一样的，就换了个名字和参数路径

# region ColorOS(Nandswap)
readonly HYBRID_SWAP_CORE="/sys/block/zram0/hybridswap_core_enable"
readonly NST='/product/bin/nandswap_tool'
BLK_OPLUS='/sys/block/zram0/hybridswap_loop_device'
readonly BLK_OPLUS_CRYPTO='/dev/block/mapper/hybridswap_crypto'

nandswap_supported(){
  if [[ -e "$HYBRID_SWAP_CORE" && -e "$NST" ]] && [[ $(kernel_compare "6.6") -lt 0 ]] && [[ "$(grep zram1 /proc/swaps)" == '' ]] && [[ "$(cat /sys/block/zram0/hybridswap_loop_device)" != 'chp' ]]; then
    return 0 # 状态0表示没问题
  else
    return 2
  fi
}

disable_nandswap(){
  if nandswap_supported ; then
    setprop persist.sys.oplus.nandswap false
    setprop persist.sys.oplus.nandswap.swapsize ''
    setprop persist.sys.oplus.nandswap.swapsize.curr ''

    echo "The system's extended memory has been disabled because it conflicts with the module configuration."
    echo '已禁用系统的拓展内存，因为与模块配置矛盾。'
  fi
}

release_nandswap(){
	if [ -f $BLK_OPLUS ]; then
		set_value 0 /sys/block/zram0/hybridswap_core_enable
		set_value 0 /sys/block/zram0/hybridswap_enable
		set_value 1 /sys/block/zram0/hybridswap_swapd_pause
		set_value 0 /sys/block/zram0/hybridswap_zram_increase
		set_value 'swapd_swappiness=0' /proc/oplus_mem/swappiness_para
		set_value '' $BLK_OPLUS
		set_value "0 0 0 0" "/dev/memcg/memory.avail_buffers"
	fi
}

# 都是一样的，Meizu和Oplus共用一个函数得了
oplus_memcg_config(){
	memcg="/dev/memcg/"
	if [ -e "/sys/fs/cgroup/memory.swapd_memcgs_param" ]; then
		memcg="/sys/fs/cgroup/"
	else
		echo apps > /dev/memcg/apps/memory.name
		echo 300 > /dev/memcg/apps/memory.app_score
	fi
	# echo "3 0 99 0 0 0 100 399 60 0 0 400 499 50 0 0 " > "${memcg}memory.swapd_memcgs_param"
	# 配置格式如
	# [levels] [minScore] [maxScore] [ub_mem2zram_ratio] [ub_zram2ufs_ratio]  [minScore] [maxScore]...
	echo "3 0 99 0 0 0 100 399 99 80 0 400 499 99 80 0 " > "${memcg}memory.swapd_memcgs_param"
	echo 400 > "${memcg}memory.app_score"
	echo root > "${memcg}memory.name"
	echo "2200 1800 2200 1536" > "${memcg}memory.avail_buffers"

	zram_size=$(cat /sys/block/zram0/disksize)
	zram_size=$(expr $zram_size / 1048576) # 别改成$(())，不支持64位数值
	zram_increase=$(cat /sys/block/zram0/*_zram_increase)
	# zram0/disksize=zram_size+zram_increase
	# memory.zram_used_limit_mb=zram_size
	# memory.zram_critical_threshold=zram_size - 128
	# oppo官方自己是这么配置的，实际上好像也不用这么严格遵守？
	echo $zram_size > /dev/memcg/memory.zram_used_limit_mb
	echo $((zram_size - 512)) > /dev/memcg/memory.zram_critical_threshold

	echo 256 > "${memcg}memory.swapd_max_reclaim_size" # oplus default 60
	echo "1000 50" > "${memcg}memory.swapd_shrink_parameter"
	echo 5000 > "${memcg}memory.max_skip_interval"
	echo 50 > "${memcg}memory.reclaim_exceed_sleep_ms"
	echo 80 > "${memcg}memory.cpuload_threshold" # oplus default 60
	echo 256 > "${memcg}memory.max_reclaimin_size_mb" # oplus default 30
	echo 80 > "${memcg}memory.zram_wm_ratio"
	echo 512 > "${memcg}memory.empty_round_skip_interval"
	echo 20 > "${memcg}memory.empty_round_check_threshold"
}

set_nandswap()
{
  zram_increase=$1 # 拓展大小 MB
  if [[ "$zram_increase" == '' ]] || [[ ! -f "$NST" ]]; then
    echo 'ERR_PARAM_OR_NO_TOOL'
    return
  fi

	block_file=/data/writeback # /data/nandswap/swapfile 可能会老被系统删
	block_size=$((zram_increase / 2))
	if [ ! -f $block_file ] || [ "$(ls -al $block_file | awk '{print $5}')" != "$block_size" ]; then
		rm -f $block_file 2>/dev/null
		dd if=/dev/zero of=$block_file bs=1M count=$block_size 2>/dev/null
	fi

	for i in {0..2} ; do
		losetup -f >/dev/null 2>&1
		sleep 1
		loop_device=$(losetup -f -s $block_file 2>&1)
		loop_device_ret=$(echo $loop_device |awk -Floop '{print $1}')
		if [ "$loop_device_ret" == "/dev/block/" ]; then
			break
		fi
		sleep 1
	done

	set_dio=$($NST -l $loop_device |awk '{print $2}')
	if [ "$set_dio" == "success" ]; then
		chmod o+w `ls -l /sys/block/zram0/hybridswap_* | grep ^'\-rw\-' | awk '{print $NF}'`
		oplus_memcg_config
		echo -n $loop_device > $BLK_OPLUS
		echo 1 > /sys/block/zram0/hybridswap_enable
		echo "$zram_increase" > /sys/block/zram0/hybridswap_zram_increase
		echo 21474836480 > /sys/block/zram0/hybridswap_quota_day # 默认10737418240，也就是每天限制10GB写入
		#Qun.Lin@AD.Performancee, 2022/4/4, change cfg to mq-deadline
		loop_name=$(echo $loop_device |awk -F/ '{print $4}')
		echo mq-deadline > /sys/block/$loop_name/queue/scheduler
	else
		echo ERR_SET_DIO
		losetup -d $loop_device
		rm -rf $block_file
	fi
}
# endregion ColorOS(Nandswap)


# region Flyme(SmartSwap)
readonly SMART_SWAP_CORE="/sys/block/zram0/smartswap_core_enable"
readonly SZT='/vendor/bin/smartzram_tool'
BLK_MEIZU='/sys/block/zram0/smartswap_loop_device'

if [[ -f /system/bin/losetup ]]; then
	alias losetup='/system/bin/losetup'
fi

smartswap_supported(){
  if [[ -e "$SMART_SWAP_CORE" && -e "$SZT" ]] && [[ $(kernel_compare "6.6") -lt 0 ]]; then
    return 0 # 状态0表示没问题
  else
    return 2
  fi
}

disable_smartswap(){
  if smartswap_supported ; then
    setprop persist.vendor.meizu.smart_zram false
    setprop persist.vendor.meizu.smart_zram.swapsize ''
    setprop persist.vendor.meizu.smart_zram.swapsize.curr ''

    echo "The system's extended memory has been disabled because it conflicts with the module configuration."
    echo '已禁用系统的拓展内存，因为与模块配置矛盾。'
  fi
}

release_smartswap(){
	if [ -f $BLK_MEIZU ]; then
		set_value 0 /sys/block/zram0/smartswap_core_enable
		set_value 0 /sys/block/zram0/smartswap_enable
		set_value 1 /sys/block/zram0/smartswap_swapd_pause
		set_value 0 /sys/block/zram0/smartswap_zram_increase
		set_value '' $BLK_MEIZU
		set_value "0 0 0 0" "/dev/memcg/memory.avail_buffers"
	fi
}

set_smartswap()
{
  zram_increase=$1 # 拓展大小 MB
  if [[ "$zram_increase" == '' ]] || [[ ! -f "$SZT" ]]; then
    echo 'ERR_PARAM_OR_NO_TOOL'
    return
  fi

	block_file=/data/writeback # /data/vendor/smart_zram/swapfile 可能会老被系统删
	block_size=$((zram_increase / 2))
	if [ ! -f $block_file ] || [ "$(ls -al $block_file | awk '{print $5}')" != "$block_size" ]; then
		rm -f $block_file 2>/dev/null
		dd if=/dev/zero of=$block_file bs=1M count=$block_size 2>/dev/null
	fi

	for i in {0..2} ; do
		losetup -f >/dev/null 2>&1
		sleep 1
		loop_device=$(losetup -f -s $block_file 2>&1)
		loop_device_ret=$(echo $loop_device |awk -Floop '{print $1}')
		if [ "$loop_device_ret" == "/dev/block/" ]; then
			break
		fi
		sleep 1
	done

	set_dio=$($SZT -l $loop_device |awk '{print $2}')
	if [ "$set_dio" == "success" ]; then
		chmod o+w `ls -l /sys/block/zram0/smartswap_* | grep ^'\-rw\-' | awk '{print $NF}'`
		oplus_memcg_config 2>/dev/null
		echo -n $loop_device > $BLK_MEIZU
		echo 1 > /sys/block/zram0/smartswap_enable
		echo "$zram_increase" > /sys/block/zram0/smartswap_zram_increase
		#Qun.Lin@AD.Performancee, 2022/4/4, change cfg to mq-deadline
		loop_name=$(echo $loop_device |awk -F/ '{print $4}')
		echo mq-deadline > /sys/block/$loop_name/queue/scheduler
	else
		echo ERR_SET_DIO
		losetup -d $loop_device
		rm -rf $block_file
	fi
}
# endregion Flyme(SmartSwap)