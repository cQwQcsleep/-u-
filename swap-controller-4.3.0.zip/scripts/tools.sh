# linux shell下的陋习，返回状态码0或者空都表示true，非0表示false
# 为了避免引起误解，这里统一用return_true和return_false来表示
alias return_false="return 99"
alias return_true="return 0"

SDK_VERSION=$(getprop ro.build.version.sdk) # 安卓sdk版本
KERNEL_VERSION=$(uname -r | cut -d'-' -f1) # 6.6.30
KERNEL_VERSION_1=$(echo $KERNEL_VERSION | cut -d'.' -f1) # 内核大版本
PLATFORM=$(getprop ro.board.platform) # soc平台
SOC=$(getprop ro.soc.model | tr 'a-z' 'A-Z') # soc型号

MEM_TOTAL_STR=$(cat /proc/meminfo | grep MemTotal)
MEM_TOTAL_KB=${MEM_TOTAL_STR:16:8}
MEM_TOTAL_GB=$(((MEM_TOTAL_KB/1024+2047)/2048*2))

# 二者取小
min(){
  if [[ $1 -lt $2 ]]; then
    echo $1
  else
    echo $2
  fi
}

# 二者取大
max(){
  if [[ $1 -gt $2 ]]; then
    echo $1
  else
    echo $2
  fi
}

# compare_versions 5.5 5.15 # 1
# compare_versions 5.5 5.5 # 0
# compare_versions 5.15 5.5 # -1
compare_versions(){
  # 可以用 printf "6.10.33\n6.6.30" | sort -V | head -n1 # 返回两个版本中较小的版本
  if [[ $1 == $2 ]]; then
    echo 0
    return
  fi
  awk -v a="$1" -v b="$2" 'BEGIN {
    split(a, va, "."); split(b, vb, ".");
    for (i = 1; i <= 3; i++) {
      if (va[i] > vb[i]) exit 2;
      if (va[i] < vb[i]) exit 1;
    }
    exit 0;
  }'
  case $? in
    0) echo 0 ;;  # 相等
    1) echo 1 ;;  # b 大于 a
    2) echo -1 ;; # b 小于 a
  esac
}

kernel_compare(){
  compare_versions "$1" "$KERNEL_VERSION"
}

# 等待开机完成和用户解锁
wait_until_login() {
  # in case of /data encryption is disabled
  while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
  done

  # in case of the user unlocked the screen
  until [ -d "/data/data/android" ]; do
    sleep 1
  done
}

# set_value value path
set_value() {
  if [[ -f $2 ]]; then
    chmod 644 $2 2>/dev/null
    echo $1 > $2 2>/dev/null || echo "    写入失败 $1 $2"
  fi
}

# lock_value value path
lock_value(){
  if [[ -f $2 ]]; then
    chmod 644 $2 2>/dev/null
    echo $1 > $2 2>/dev/null || echo "    写入失败 $1 $2"
    chown root:root $2 2>/dev/null
    chmod 444 $2 2>/dev/null
  fi
}

# 修改system.prop
update_prop() {
  prop="$1"
  value="$2"
  sed -i "s/^$prop=.*/$prop=$value/" $MODPATH/system.prop
  # cat $MODPATH/system.prop | grep $prop
}
