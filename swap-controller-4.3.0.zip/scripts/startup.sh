DIR=${0%/*}

source $DIR/tools.sh
source $DIR/tools.startup.sh
source $DIR/tools.nandswap.sh

import_config

readonly SWAP_FILE='/data/swapfile'
readonly LOOP_SAVE='vtools.swap.loop'

# 写明用哪个swapon，避免用到busybox的
if [[ -f /system/bin/swapon ]]; then
  alias swapon='/system/bin/swapon'
  alias swapoff='/system/bin/swapoff'
  alias mkswap='/system/bin/mkswap'
elif [[ -f /vendor/bin/swapon ]]; then
  alias swapon='/vendor/bin/swapon'
  alias swapoff='/vendor/bin/swapoff'
  alias mkswap='/vendor/bin/mkswap'
fi
if [[ -f /system/bin/dd ]]; then
  alias dd='/system/bin/dd'
elif [[ -f /vendor/bin/dd ]]; then
  alias dd='/vendor/bin/dd'
fi

COLOR_OS=$(getprop ro.build.version.oplusrom.display)
MIUI=$(getprop ro.miui.ui.version.name)

# alias losetup="busybox losetup"

# 获取用于挂载swapfile的回环设备
get_swap_loop(){
  # 优先使用之前记录用过的回环设备
  current_loop=$(getprop $LOOP_SAVE)
  if [[ "$current_loop" != "" ]]; then
    echo $current_loop
    return
  fi
  get_next_loop
}

# 获取下一个可用的loop设备
get_next_loop() {
  # 尝试创建一个新的回环设备
  losetup -f >/dev/null 2>&1
  i=$(losetup -f | grep -e -o '[0-9]{1,}' 2>/dev/null)
  if [[ "$i" != "" ]]; then
    echo "/dev/block/loop$i"
    return
  fi

  # 如果创建不了新的了，从已创建的里面找一个空闲的
  used="$(blkid | grep /dev/block/loop)"
  for i in $(seq 1 99); do
    loop="/dev/block/loop$i"
    if [[ -e $loop ]] && [[ "$(echo $used | grep $loop)" = "" ]]; then
      echo $loop
      return
    fi
  done
}

# 优化loop设备的性能(也许)
optimize_loop(){
  loop_path_1=$1
  loop_name=$(echo $loop_path_1 | awk -F/ '{print $4}')
  loop_queue=/sys/block/$loop_name/queue
  if [[ -d "$loop_queue" ]]; then
    echo 4096 > $loop_queue/max_sectors_kb
    echo 4096 > $loop_queue/read_ahead_kb
    echo mq-deadline > $loop_queue/scheduler
    echo 256 > $loop_queue/nr_requests
    echo 0 > $loop_queue/nomerges
    # echo 1024 > $loop_queue/max_segments
  fi
}

set_swap() {
  echo "*************************"

  echo "设置Swapfile"
  if [[ "$swap" == "true" ]] && [[ "$swap_size" != "" ]]; then
    file_size=$(stat -c %s $SWAP_FILE)
    file_size=$(expr $file_size / 1024 / 1024)
    if [[ $file_size != "$swap_size" ]]; then
      echo "    删除已有$SWAP_FILE"
      rm -f $SWAP_FILE 2>/dev/null
    fi
    set_value true /sys/kernel/mm/swap/vma_ra_enabled

    # 是否已经创建文件
    if [[ ! -f $SWAP_FILE ]]; then
      echo "    创建swapfile"
      if [[ $KERNEL_VERSION_1 -ge 5 ]]; then
        fallocate -l ${swap_size}M $SWAP_FILE
      else
        dd if=/dev/zero of=$SWAP_FILE bs=1m count=${swap_size} > /dev/null
      fi
      chmod 0664 $SWAP_FILE > /dev/null
      chown system:system $SWAP_FILE > /dev/null
    fi

    # 判断挂载点
    mount_point=$SWAP_FILE
    # 如果需要挂载为回环设备，则先挂载并记录挂载点参数
    if [[ "$swap_use_loop" == "true" ]]; then
      echo "    获取下一个可用回环设备"
      mount_point=$(get_swap_loop)

      if [[ "$mount_point" == "" ]]; then
        echo '  所有回环设备都已被占用，SWAP无法完成挂载！' 1>&2
        return
      fi

      echo "    删除已有回环设备" 
      [[ -e $mount_point ]] && losetup -d $mount_point 2>/dev/null

      echo "    初始化swapfile"
      mkswap $SWAP_FILE >/dev/null

      echo "    挂载回环设备 $mount_point"
      losetup $mount_point $SWAP_FILE
      setprop $LOOP_SAVE $mount_point
      optimize_loop
    else
      echo "    初始化swapfile"
      mkswap $SWAP_FILE >/dev/null
    fi

    echo "    开启Swapfile"
    # 判断是否自定义优先级
    if [[ "$swap_priority" != "" && "$swap_priority" -gt -1 ]]; then
      swapon $mount_point -p $swap_priority >/dev/null
    else
      swapon $mount_point > /dev/null
    fi
  else
    echo "    未启用Swapfile"
    rm -f $SWAP_FILE 2>/dev/null
  fi
}

set_swap_ext() {
  # 因为 OPPO 的 hybridswap 是一次性配置，改了ZRAM后基本就废了
  # 但分配的分区并不会变成0，不用也浪费，不如用它开个swapfile
  if [[ -e "$BLK_OPLUS_CRYPTO" ]] && [[ "$(cat $BLK_OPLUS)" == '' || "$(cat $BLK_OPLUS)" == none* ]]; then
    mkswap "$BLK_OPLUS_CRYPTO" >/dev/null
    swapon "$BLK_OPLUS_CRYPTO" >/dev/null
  fi
}

set_zram() {
  echo "*************************"
  if [[ ! -e /dev/block/zram0 ]]; then
    if [[ -e /sys/class/zram-control ]]; then
      cat /sys/class/zram-control/hot_add
    else
      echo '  内核不支持ZRAM!'
      return
    fi
  fi

  if [[ "$zram" == "true" ]] && [[ "$zram_size" != "" ]]; then
    echo "设置ZRAM"

    swapoff /dev/block/zram0 2>/dev/null
    # swapoff /dev/block/zram1 2>/dev/null

    if [[ "$zram_size" == "0" ]]; then
      return
    fi

    # 读取 ZRAM Writeback配置
    bd_path=/sys/block/zram0/backing_dev
    backing_dev=''
    if [[ -e $bd_path ]]; then
      backing_dev=$(cat $bd_path | tr -d '()')
    fi

    set_value 1 /sys/block/zram0/reset
    set_value 4 /sys/block/zram0/max_comp_streams

    echo "    设置ZRAM压缩方式" $comp_algorithm
    for alg in $comp_algorithm zstd zstdn lz4k lz4 lzo-rle lzo; do
      echo $alg > /sys/block/zram0/comp_algorithm 2>/dev/null && break
    done

    zram_increase=0
    if nandswap_supported && [[ "$zram_writeback" == "true" ]]; then
      zram_increase=4096
    elif smartswap_supported && [[ "$zram_writeback" == "true" ]]; then
      zram_increase=4096
    elif [[ -f $bd_path ]]; then
      if [[ "$zram_writeback" == "true" ]]; then
        set_zram_writeback
        echo "    配置ZRAM Writeback"
      elif [[ "$zram_writeback" == "default" ]]; then
        echo "    恢复ZRAM Writeback $backing_dev"
        set_value 0 /sys/block/zram0/writeback_limit_enable
        # 正常情况，关闭重启zram并不会导致backing_dev设置失效，但保险起见还是恢复配置一次
        if [[ "$backing_dev" != '' ]] && [[ "$backing_dev" != none* ]]; then
          loop_name=$(echo $backing_dev | awk -F/ '{print $4}')
          if [[ "$loop_name" == loop* ]] && [ ! -e /sys/block/$loop_name/loop/backing_file ]; then
            echo "    ${backing_dev}对应的文件已丢失，禁用ZRAM Writeback"
            set_value none $bd_path
          else
            echo "    格式化 $backing_dev"
            mkswap $bd_path > /dev/null
            echo -n "$backing_dev" > $bd_path
          fi
        fi
      else
        echo "    禁用ZRAM Writeback"
        set_value none $bd_path
      fi
    fi

    disk_size=$zram_size
    if [ "$zram_increase" -gt 0 ]; then
      disk_size=$((zram_size+zram_increase))
    fi
    echo "    设置ZRAM大小" $disk_size "(+${zram_increase})"
    echo ${disk_size}m > /sys/block/zram0/disksize

    echo "    初始化ZRAM"
    mkswap /dev/block/zram0 > /dev/null

    set_value 32768 /dev/memcg/memory.zram_used_limit_mb
    set_value 32768 /dev/memcg/memory.zram_critical_threshold
    set_value 256 /dev/memcg/memory.max_reclaimin_size_mb
    set_value 256 /dev/memcg/memory.swapd_max_reclaim_size
    set_value 80 /dev/memcg/memory.cpuload_threshold

    echo "    启动ZRAM"
    swapon /dev/block/zram0 -p 0 >/dev/null
    if nandswap_supported && [[ "$zram_writeback" == "true" ]]; then
      echo "    配置ZRAM Writeback"
      set_nandswap $zram_increase
    elif smartswap_supported && [[ "$zram_writeback" == "true" ]]; then
      echo "    配置ZRAM Writeback"
      set_smartswap $zram_increase
    else
      release_nandswap
      release_smartswap
    fi
  else
    echo "未配置ZRAM"
  fi

  # setprop persist.sys.zram_enabled 1
}

set_vm_params() {
  echo "*************************"
  if [[ "$watermark_scale_factor" != "" ]]; then
    echo "设置watermark_scale_factor $watermark_scale_factor"
    set_value "$watermark_scale_factor" /proc/sys/vm/watermark_scale_factor
  fi
  lock_value 0 /proc/sys/vm/watermark_boost_factor

  path='/proc/sys/vm/extra_free_kbytes'
  if [[ -f $path ]] && [[ "$extra_free_kbytes" != "" ]]; then
    echo "设置extra_free_kbytes [$extra_free_kbytes]"
    set_value "$extra_free_kbytes" $path
    resetprop sys.sysctl.extra_free_kbytes "$extra_free_kbytes"
  fi
  path2='/proc/sys/vm/min_free_kbytes'

  echo "设置min_free_kbytes"
  # 加大min_free_kbytes有助于减少系统异常重启。一些扩容了内存的设备，或长期高负荷运行的设备
  min_free_kbytes=20480
  if [[ $MEM_TOTAL_KB -gt 4194304 ]]; then
    min_free_kbytes=32768
  fi
  if [[ $(cat $path2) -lt $min_free_kbytes ]]; then
    set_value $min_free_kbytes $path2
  fi


  if [[ "$swappiness" != "" ]]; then
    echo "设置swappiness [$swappiness]"
    lock_value $swappiness /proc/sys/vm/swappiness
    lock_value $swappiness /dev/memcg/memory.swappiness
    lock_value $swappiness /dev/memcg/apps/memory.swappiness
    lock_value $swappiness /sys/fs/cgroup/memory/apps/memory.swappiness
    lock_value $swappiness /sys/fs/cgroup/memory/memory.swappiness
    set_value $swappiness /sys/module/zram_opt/parameters/vm_swappiness
    oplus_mem=/proc/oplus_mem/swappiness_para
    if [[ -f $oplus_mem ]]; then
      set_value "vm_swappiness=$swappiness" $oplus_mem
      set_value "kswapd_swappiness=$swappiness" $oplus_mem
      set_value "swapd_swappiness=$swappiness" $oplus_mem
      set_value direct_swappiness=`max $((swappiness-25)) 1` $oplus_mem
      echo $swappiness 0 $swappiness 0 > /proc/oplus_mem/dynamic_swappiness
    fi
    oplus_opt=/sys/module/oplus_bsp_zram_opt/parameters
    if [[ -d $oplus_opt ]]; then
      set_value $swappiness $oplus_opt/vm_swappiness
      set_value 0 $oplus_opt/swappiness_threshold1_size
      set_value 0 $oplus_opt/swappiness_threshold2_size
    fi
  else
    echo "未配置swappiness"
  fi

  echo "设置cache"
  # 降低了读写缓存，对于目前的UFS3闪存来说，IO性能足够，并不需要太多内存缓存来提高性能
  set_value 5 /proc/sys/vm/dirty_background_ratio
  set_value 10 /proc/sys/vm/dirty_ratio
  set_value 5000 /proc/sys/vm/dirty_expire_centisecs
  set_value 10000 /proc/sys/vm/dirty_writeback_centisecs
  set_value 150 /proc/sys/vm/vfs_cache_pressure
  # set_value 128 /sys/block/sda/queue/read_ahead_kb

  echo "设置其它vm参数"
  # set_value 1 /proc/sys/vm/swap_ratio_enable
  # set_value 75 /proc/sys/vm/swap_ratio
  set_value 0 /proc/sys/vm/swap_ratio_enable
  set_value 4 /proc/sys/vm/kswapd_threads
  set_value 50 /sys/module/vmpressure/parameters/allocstall_threshold
  # 每次换入的内存页，3表示2的三次方，即8页
  #   每页的大小可以通过 `getcon PAGESIZE` 查看，一般是4KB
  if [[ $comp_algorithm == zstd* ]] || [[ $comp_algorithm == deflate ]]; then
    set_value 0 /proc/sys/vm/page-cluster
  else
    set_value 1 /proc/sys/vm/page-cluster
  fi
  # 杀死触发oom的那个进程
  set_value 0 /proc/sys/vm/oom_kill_allocating_task
  # 是否打印 oom日志
  set_value 0 /proc/sys/vm/oom_dump_tasks
  # 是否要允许压缩匿名页
  set_value 1 /proc/sys/vm/compact_unevictable_allowed
  # 后台进行压缩的积极性(0~100)
  set_value 20 /proc/sys/vm/compaction_proactiveness
  # CommitLimit=Swap+Zram+(RAM * overcommit_ratio / 100)，当overcommit_memory为1时失效
  # set_value 100 /proc/sys/vm/overcommit_ratio
  lock_value 1 /proc/sys/vm/overcommit_memory
  # 触发oom后怎么抛异常
  set_value 0 /proc/sys/vm/panic_on_oom
}

set_lmk_params() {
  echo "*************************"
  echo "设置lmk参数"

  # MIUI 12
  if [[ "$MIUI" != '' ]]; then
    resetprop persist.sys.minfree_6g "16384,20480,32768,131072,262144,384000"
    resetprop persist.sys.minfree_8g "16384,20480,32768,131072,384000,524288"
    resetprop persist.sys.minfree_12g "16384,20480,131072,384000,524288,819200"
    if [[ $MEM_TOTAL_GB -gt 6 ]]; then
      resetprop persist.sys.minfree_def "16384,20480,32768,131072,384000,524288"
    else
      resetprop persist.sys.minfree_def "16384,20480,32768,131072,262144,384000"
    fi
  fi


  lmk='/sys/module/lowmemorykiller/parameters'
  # Linux Kernel 4.9 前的内核
  if [[ -d $lmk ]]; then
    # > 8G
    if [[ $MEM_TOTAL_GB -gt 8 ]]; then
      set_value "4096,5120,32768,96000,131072,204800" $lmk/minfree
    # > 6G
    elif [[ $MEM_TOTAL_GB -gt 6 ]]; then
      set_value "4096,5120,8192,32768,96000,131072" $lmk/minfree
    # > 4GB
    elif [[ $MEM_TOTAL_GB -gt 4 ]]; then
      set_value "4096,5120,8192,32768,65536,96000" $lmk/minfree
    # > 3GB
    elif [[ $MEM_TOTAL_GB -gt 3 ]]; then
      set_value "4096,5120,8192,24576,32768,47360" $lmk/minfree
    # > 2GB
    elif [[ $MEM_TOTAL_GB -gt 2 ]]; then
      set_value "4096,5120,8192,16384,24576,39936" $lmk/minfree
    else
      set_value "4096,5120,8192,10240,16384,24576" $lmk/minfree
    fi

    set_value 53059 $lmk/vmpressure_file_min
    set_value 0 $lmk/enable_adaptive_lmk
    set_value 1 $lmk/oom_reaper

  # Android Q+
  elif [[ $SDK_VERSION -gt 28 && $KERNEL_VERSION_1 -lt 6 ]]; then
    minfree_levels=""
    # > 8G
    if [[ $MEM_TOTAL_GB -gt 8 ]]; then
      minfree_levels="4096:0,5120:100,32768:200,96000:250,131072:900,204800:950"
    # > 6G
    elif [[ $MEM_TOTAL_GB -gt 6 ]]; then
      minfree_levels="4096:0,5120:100,8192:200,32768:250,96000:900,131072:950"
    # > 4GB
    elif [[ $MEM_TOTAL_GB -gt 4 ]]; then
      minfree_levels="4096:0,5120:100,8192:200,32768:250,65536:900,96000:950"
    # > 3GB
    elif [[ $MEM_TOTAL_GB -gt 3 ]]; then
      minfree_levels="4096:0,5120:100,8192:200,24576:250,32768:900,47360:950"
    # > 2GB
    elif [[ $MEM_TOTAL_GB -gt 2 ]]; then
      minfree_levels="4096:0,5120:100,8192:200,16384:250,24576:900,39936:950"
    else
      minfree_levels="4096:0,5120:100,8192:200,10240:250,16384:900,24576:950"
    fi

    resetprop sys.lmk.minfree_levels $minfree_levels
    # MIUI Only
    if [[ $KERNEL_VERSION_1 -lt 5 ]] && [[ "$MIUI" != '' ]]; then
      sleep 2 && stop lmkd && start lmkd
      resetprop sys.lmk.minfree_levels $minfree_levels
    fi

    # 版本低于4.12的内核还会保留lowmemorykiller
    # 但禁用它可能导致内存不足时死机
    # set_value 0 /sys/module/lowmemorykiller/parameters/enable_lmk
  fi

  prop=ro.lmk.limit_killing_array_kb
  if [[ "$COLOR_OS" != '' ]] && [[ $(getprop $prop) != 409600* ]]; then
    resetprop $prop '409600,358400,281600,204800'
    # lmkd --reinit
    sleep 10 && sync && stop lmkd && sleep 1 && start lmkd
  fi

  # Found in Xiaomi 15 HyperOS3
  set_value 0 /sys/kernel/low_free/low_free_enable
  set_value 0 /sys/kernel/mi_reclaim/greclaim_enable
}

set_zram_writeback() {
  loop_path=$(get_swap_loop)
  if [[ "$loop_path" == "" ]]; then
    echo '  所有回环设备都已被占用，ZRAM Writeback无法配置！' 1>&2
    return
  fi

  wbf="/data/writeback"
  for f in $EXTM_FILES; do
    if [[ -f $f ]]; then
      wbf=$f
    fi
  done

  if [[ ! -f $wbf ]]; then
    if [[ "$(cat /sys/block/zram0/comp_algorithm)" = lz* ]]; then
      size=$((zram_size*5/2))
    else
      size=$((zram_size/3))
    fi
    size=$(max $size 1024) # 限制至少1024M
    size=$(min $size 8192) # 限制最多8192M
    if [[ $KERNEL_VERSION_1 -ge 5 ]]; then
      fallocate -l ${size}M $wbf || dd if=/dev/zero of=$wbf bs=1m count=$size
    else
      dd if=/dev/zero of=$wbf bs=1m count=$size
    fi
    chmod 664 $wbf 2>/dev/null
    chown system:system $wbf 2>/dev/null
  fi

  losetup $loop_path $wbf
  mkswap $loop_path > /dev/null
  echo -n $loop_path > /sys/block/zram0/backing_dev
  optimize_loop "$loop_path"
  set_value 0 /sys/block/zram0/writeback_limit_enable
}

dis_reclaim() {
  ppr=/sys/module/process_reclaim/parameters
  # process_reclaim 高通特有，优缺点同样明显(能有效提高swap效率，但会增加额外的开销)
  if [[ -d $ppr ]]; then
    set_value 0 $ppr/enable_process_reclaim
  fi

  # 禁用 mi_reclaim
  set_value 0 /sys/kernel/mi_reclaim/enable

  # 尝试禁用小米的rtmm
  mi_rtmm=''
  if [[ -d '/d/rtmm' ]]; then
    mi_rtmm=/d/rtmm/reclaim
  elif [[ -d '/sys/kernel/mm/rtmm' ]]; then
    mi_rtmm='/sys/kernel/mm/rtmm'
  else
    return
  fi

  chmod 000 $mi_rtmm/reclaim/auto_reclaim 2>/dev/null
  chown root:root $mi_rtmm/reclaim/auto_reclaim 2>/dev/null
  chmod 000 $mi_rtmm/reclaim/global_reclaim 2>/dev/null
  chown root:root $mi_rtmm/reclaim/global_reclaim 2>/dev/null
  chmod 000 $mi_rtmm/reclaim/proc_reclaim 2>/dev/null
  chown root:root $mi_rtmm/reclaim/proc_reclaim 2>/dev/null
  chmod 000 $mi_rtmm/reclaim/kill 2>/dev/null
  chown root:root $mi_rtmm/reclaim/kill 2>/dev/null
  chown root:root $mi_rtmm/compact/compact_memory 2>/dev/null

  if [[ -d /sys/module/perf_helper/mimd ]]; then
    lock_value -1 /sys/module/perf_helper/mimd/mimdtrigger
    stop mimd-service2_0 2>/dev/null
    stop mimd-service 2>/dev/null
  fi
}

alias a_conf="device_config put activity_manager"
device_configs() {
  echo '写入 device_config'

  if [[ "$(which device_config)" != '' ]]; then
    a_conf max_cached_processes 32768
    a_conf max_phantom_processes 32768

    nke=no_kill_cached_processes_until_boot_completed
    nkd=no_kill_cached_processes_post_boot_completed_duration_millis
    a_conf $nkd 2147483647
    # a_conf $nke true
    # Realme GT NEO不知为何，nkd写进去之后实际总是0，nke也是false，特殊处理下
    if [ "$(dumpsys activity settings | grep $nkd=0)" != '' ]; then
      a_conf $nkd 999999999
      a_conf $nke false && a_conf $nke true
    fi

    a_conf max_empty_time_millis 2147483647
    # a_conf kill_bg_restricted_cached_idle false
    a_conf kill_bg_restricted_cached_idle_settle_time 2147483647
    if [[ "$(getprop ro.lmk.use_psi)" == 'true' ]]; then
      device_config put lmkd_native use_minfree_levels false
    fi
    device_config delete lmkd_native thrashing_limit_critical 2>&1 > /dev/null 
    a_conf use_compaction false
    a_conf proactive_kills_enabled false
  fi

  settings put global settings_enable_monitor_phantom_procs false 2>&1 >/dev/null
  if [[ $(settings get secure allowed_kill_battery_temp_threshhold) != '' ]]; then
    settings put secure allowed_kill_battery_temp_threshhold 65535 2>&1 >/dev/null
  fi
}

# ColorOS/HyperOS
os_config(){
  echo '更改特定系统参数'

  # 在ColorOS上占用巨量内存...
  set_value never /sys/kernel/mm/transparent_hugepage/enabled
  set_value never /sys/kernel/mm/transparent_hugepage/defrag

  props_to_false="persist.sys.precache.enable persist.sys.prestart.proc persist.sys.preload.enable persist.vendor.enable.preload persist.sys.app_dexfile_preload.enable"
  for prop in $props_to_false; do
    if [[ "$(getprop $prop)" == 'true' ]]; then
      setprop $prop false
    fi
  done
  for prop in persist.sys.precache.number persist.sys.lmk.oplus.kill_memleak_process; do
    if [[ "$(getprop $prop)" != '' ]]; then
      setprop $prop 0
    fi
  done
  if [[ -f /sys/block/zram0/hybridswap_meminfo ]]; then
    if [[ $(head -1 /sys/block/zram0/hybridswap_meminfo | tr -s ' ' | cut -d' ' -f2) -gt 0 ]]; then
      memcg_enable=true
    else
      memcg_enable=false
    fi
    for prop in persist.sys.oplus.hybridswap_app_memcg persist.sys.oplus.hybridswap_app_uid_memcg persist.sys.oplus.fg.protect.condition; do
      if [[ "$(getprop $prop)" != '' ]]; then
        setprop $prop $memcg_enable
      fi
    done
  elif [[ -f /sys/block/zram0/smartswap_meminfo ]]; then
    if [[ $(head -1 /sys/block/zram0/smartswap_meminfo | tr -s ' ' | cut -d' ' -f2) -gt 0 ]]; then
      memcg_enable=true
    else
      memcg_enable=false
    fi
  elif [[ $(getprop init.svc.mimd-service2_0) == 'running' ]] || [[ $(getprop init.svc.mimd-service) == 'running' ]]; then
    memcg_enable=true
  else
    for prop in persist.sys.oplus.hybridswap_app_uid_memcg persist.sys.oplus.hybridswap_app_memcg ro.oplus.osense_app_memc
    do
      if [[ "$(getprop prop)" == "true" ]]; then
        memcg_enable=true
        break
      fi
    done
  fi

  # Linux Kernel < 5 大概率不支持LruGen，Linux Kernel > 6.6 又和memcg各种冲突宕机
  if [[ $KERNEL_VERSION_1 -ge 5 && "$memcg_enable" != 'true' ]]; then
    # 开启lru gen可能导致swappines设置失效，低内存占用的情况下kswapd疯狂运转
    # 如果内存足够，保持默认就好了
    # 如果设备制造厂商经过调优觉得开了更好那就开，默认没开就算了
    if [[ $MEM_TOTAL_KB -lt 12582912 ]]; then
      set_value Y /sys/kernel/mm/lru_gen/enabled
    fi
  fi

  # am force-stop com.oplus.athena
  if [[ "$COLOR_OS" != '' ]]; then
    dumpsys osensemanager memory resrelease switch 0
    dumpsys osensemanager memory swap disable # dumpsys osensemanager memory swap enable
    dumpsys osensemanager memory gsa set appMinBgCount 255
    dumpsys osensemanager memory gsa set thermalThreshold 50
    # sh $DIR/tools.romupdate.sh patch_update_list
  fi
}

process_opt(){
  if  [[ "$memcg_enable" != 'true' ]]; then
    sleep 2
    rm -r /dev/memcg/apps 2>/dev/null
    for dir in /dev/memcg/apps/uid_*; do
      cat "$dir/cgroup.procs" | while read pid; do
        echo "$pid" > /dev/memcg/cgroup.procs
      done
    done
    sleep 1
    rm -r /dev/memcg/apps 2>/dev/null
  fi

  echo '关键进程保护'
  key_swappines=0
  if [[ "$COLOR_OS" != '' ]]; then
    key_swappines=30 # ColorOS 物理内存超过80%卡爆，完全不让重要进程进zram反而更卡
  fi
  if [[ -d /dev/memcg/system ]] && [[ $MEM_TOTAL_GB -ge 12 ]]; then
    init_group 'system/active_fg' $key_swappines
    for app in com.android.systemui com.miui.home com.android.launcher surfaceflinger system_server android.hardware.graphics.composer vendor.qti.hardware.display.composer-service; do
      pid=$(pidof $app || pgrep -f $app | head -n 1)
      if [[ "$pid" != "" ]]; then
        memcg=$(cat "/proc/$pid/cgroup" | grep 'memory:' | cut -d'/' -f3)
        if [[ "$memcg" == "" ]]; then
          echo "$pid" > /dev/memcg/system/active_fg/cgroup.procs
        fi
      fi
    done
  fi
}

readonly EXTM_FILES="/data/extm/extm_file /data/nandswap/swapfile /data/vendor/swap/zram /data/writeback"
if [[ "$zram" == "false" ]]; then
  echo 'ZRAM将保持系统默认配置'
  wait_until_login
  sleep 10
else
  echo "等待解锁屏幕"
  swapoff /dev/block/zram0 2>/dev/null
  if [[ $zram_writeback == 'false' ]]; then
    # setprop persist.miui.extm.enable 0
    if [[ "$(getprop persist.miui.extm.enable)" != "0" ]]; then
      setprop persist.miui.extm.enable 0
    fi
    for f in $EXTM_FILES; do
      rm -f $f 2>/dev/null
    done
  fi
  wait_until_login
  sleep 10
  echo "关闭ZRAM"
  swapoff /dev/block/zram0 2>/dev/null
fi

set_value off /sys/kernel/mm/damon/admin/kdamonds/0/state
set_value off /sys/kernel/mm/damon/admin/kdamonds/1/state
lock_value 0 /sys/kernel/mm/damon/admin/kdamonds/nr_kdamonds
dis_reclaim

set_zram
set_swap_ext
set_swap
set_lmk_params
set_vm_params
device_configs
os_config
process_opt

if [ -f "$MODPATH/scripts/tool.log.sh" ]; then
  nohup sh $MODPATH/scripts/tool.log.sh > /sdcard/kill.log 2>&1 &
fi
