DIR=${0%/*}
source $DIR/tools.sh
source $DIR/tools.startup.sh
import_config

# 解析配置
if [[ "$daemon_service" == "" || "$daemon_service" == "off" ]]; then
  # 未配置或不支持
  echo '未启用[daemon_service]'
  exit 0
fi
# 设置默认的内存使用率限制
if [[ "$daemon_used_limit" == '' ]]; then
  daemon_used_limit='175%'
fi

if [[ -f /sys/fs/cgroup/memory/memory.swappiness ]]; then
  readonly SCENE_MEMCG="/sys/fs/cgroup/memory"
elif [[ -f /dev/memcg/memory.swappiness ]]; then
  readonly SCENE_MEMCG="/dev/memcg"
fi

if [[ "$SCENE_MEMCG" != "" ]]; then
  echo "创建cgroup"

  nom_swappiness=$(cat /proc/sys/vm/swappiness)
  sys_swappiness=60
  active_swappiness=60
  idle_swappiness=$(get_swappiness_max)
  if [[ $KERNEL_VERSION_1 -ge 5 ]]; then
    active_swappiness=125
  fi
  sys_swappiness=$(min $sys_swappiness $nom_swappiness)
  active_swappiness=$(min $active_swappiness $nom_swappiness)

  # remove cgroups
  for i in $(seq 0 4); do
    for dir in $(find $SCENE_MEMCG -name *procs | xargs dirname); do
      rmdir $dir 2>/dev/null
    done
  done
  init_group apps $nom_swappiness
  init_group system $sys_swappiness
  init_group scene_active $active_swappiness
  init_group scene_idle $idle_swappiness

  find $SCENE_MEMCG -name memory.move_charge_at_immigrate | while read row; do
    echo 1 > $row
  done


  if [[ "$daemon_service" == "lazy" ]]; then
    limit=$((MEM_TOTAL_KB/1024/4))
    limit=$(min $limit 1024)
    echo ${limit}M > $SCENE_MEMCG/scene_idle/memory.soft_limit_in_bytes
  fi
else
  if [[ "$daemon_service" != "basic" ]]; then
    daemon_service="basic"
  fi
  echo "  你的内核不支持cgroup(memory)"
fi


echo "  启动cgroup配置服务"
echo '' > /cache/swap_daemon.log
nohup dalvikvm -cp $MODPATH/scripts/service.dex Main "$daemon_service" "$daemon_used_limit" >> /cache/cgroup_opt.log 2>&1 &
