#!/system/bin/sh

update_update_list() {
  name="$1" # 例如 sys_clear_config
  xml="$2"  # 例如 /data/adb/modules/scene_swap_controller/my_product/etc/extension/sys_clear_config.xml
  if [ ! -f "$xml" ]; then
    # echo "File $xml does not exist."
    return
  fi

  provider=content://com.oplus.romupdate.provider.db/update_list
  version=$(date +%Y%m%d%H) # $(date +%Y%m%d%H%M)
  values=$(cat "$xml")
  # 替换 <filter-name>xxx</filter-name> 为 <filter-name>$name</filter-name> filterName和文件名不一致会被略过加载
  # values="${values//<filter-name>*<\/filter-name>/<filter-name>$name<\/filter-name>}"
  # values="${values//<version>*<\/version>/<version>$version</version>}"
  # values="${values//\:/\\:}" # 转义: 避免遇到:就出错
  values=$(echo "$values" | sed "s|<filter-name>.*</filter-name>|<filter-name>$name</filter-name>|g")
  values=$(echo "$values" | sed "s|<version>.*</version>|<version>$version</version>|g")
  values=$(echo "$values" | sed 's/:/\\:/g')

  content delete --uri $provider --where "filterName='$name'"
  content insert --uri $provider \
  --bind filterName:s:$name \
  --bind version:s:$version \
  --bind xml:s:"$values" \
  --bind isOpen:i:1 # && echo "Updated $name to ROM Update System."
}

patch_update_list() {
  clear_update_list
  sync && sleep 2
  rom_update_db=/data/user_de/0/com.oplus.romupdate/databases/rom_update.db
  if [ -f $rom_update_db ]; then
    cp -pf $rom_update_db $rom_update_db.bak
  fi

  if [ "$MODPATH" = '' ]; then
    MODPATH="/data/adb/modules/scene_swap_controller"
  fi
  # patched="$MODPATH/my_product/etc/extension"
  patched="$MODPATH/athena"
  update_update_list "sys_athena_custom_config_list" "$patched/sys_athena_custom_config_list.xml"
  update_update_list "sys_custom_clear_config" "$patched/sys_custom_clear_config.xml"
  # update_update_list "sys_osense_common_config" "$patched/sys_osense_common_config.xml"
}

query_update_list() {
  name=$1
  if [ "$name" = '' ]; then
    content query --uri content://com.oplus.romupdate.provider.db/update_list --projection filterName
  else
    content query --uri content://com.oplus.romupdate.provider.db/update_list --projection xml --where "filterName='$1'"
  fi
}

clear_update_list(){
  provider=content://com.oplus.romupdate.provider.db/update_list
  content delete --uri $provider --where "filterName='sys_athena_custom_config_list'"
  content delete --uri $provider --where "filterName='sys_custom_clear_config'"
  content delete --uri $provider --where "filterName='sys_osense_common_config'"
}

$1
