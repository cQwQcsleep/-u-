# 检测UFS健康
ufs_health_ok() {
  bDeviceLifeTimeEstA=$(cat /sys/devices/platform/soc/*ufshc*/health_descriptor/life_time_estimation_a 2>/dev/null)
  if [[ "$bDeviceLifeTimeEstA" == "" ]]; then
    mi_health_desc=/sys/class/mi_memory/mi_memory_device/ufshcd0/dump_health_desc
    if [[ -f $mi_health_desc ]];then
      bDeviceLifeTimeEstA=$(grep bDeviceLifeTimeEstA $mi_health_desc 2>/dev/null | cut -f2 -d '=' | cut -f2 -d ' ')
    else
      bDeviceLifeTimeEstA=$(grep bDeviceLifeTimeEstA /sys/kernel/debug/*.ufshc/dump_health_desc 2>/dev/null | cut -f2 -d '=' | cut -f2 -d ' ')
    fi

    if [[ "$bDeviceLifeTimeEstA" == "" ]]; then
      dump_files=$(find /sys -name "dump_*_desc" | grep ufshc)
      for line in $dump_files
      do
        str=$(grep 'bDeviceLifeTimeEstA' $line | cut -f2 -d '=' | cut -f2 -d ' ')
        if [[ "$str" != "" ]]; then
          bDeviceLifeTimeEstA="$str"
        fi
      done
    fi

    if [[ "$bDeviceLifeTimeEstA" == "" ]];then
      files=$(find /sys -name "life_time_estimation_a" | grep ufshc)
      for line in $files
      do
        str=$(cat $line)
        if [[ "$str" != "" ]]; then
          bDeviceLifeTimeEstA="$str"
        fi
      done
    fi
  fi

  case "$bDeviceLifeTimeEstA" in
    "0x01"|"0x1"|"0x02"|"0x2")
      return_true
    ;;
    *)
      return_false
    ;;
  esac
}

# 获取ufs版本
ufs_version(){
  mi_ufs=$(grep ufs_version /sys/class/mi_memory/mi_memory_device/ufshcd0/show_hba 2>/dev/null| awk '{print $3}')
  if [[ "$mi_ufs" != "" ]]; then
    # 如 0x300 -> 3.0 和 0x400 -> 4.0
    echo ${mi_ufs:2:1}.0
  else
    # 根据特性支持情况判断ufs协议版本，准确率一般
    ufs_features_qcom='/sys/devices/platform/soc/*.ufshc*/device_descriptor/ufs_features'
    ufs_features_mtk='/sys/devices/platform/*ufshc*/device_descriptor/ufs_features'
    ufs_features=$(cat $ufs_features_qcom 2>/dev/null || cat $ufs_features_mtk 2>/dev/null)

    if [[ "$ufs_features" == "0x33" ]]; then
      echo '4.0'
    elif [[ "$ufs_features" == "0x83" ]]; then
      echo '3.1'
    elif [[ "$ufs_features" == "0x81" ]]; then
      echo '3.0'
    fi
  fi
}

# 获取soc最高频率
get_soc_max_freq(){
  max=0
  for c in /sys/devices/system/cpu/cpufreq/policy*;do
    freq=$(cat $c/cpuinfo_max_freq)
    if [[ $freq -gt $max ]]; then
      max=$freq
    fi
  done
  echo $max
}

# 监测是否是高性能soc
hp_soc() {
  # 8en2:341 8+:431 D8100:431 D1000:44 765G:611 730G:62
  clusters=''
  for policy in /sys/devices/system/cpu/cpufreq/policy*
  do
    clusters=${clusters}$(cat $policy/related_cpus | awk '{print NF}')
  done

  if [[ "$clusters" == "431" || "$clusters" == "341" || "$clusters" == "2321" || $(get_soc_max_freq) -gt 3000000 ]]; then
    return_true
  else
    return_false
  fi
}

# 检测swappiness支持的最大值
get_swappiness_max() {
  current=$(cat /proc/sys/vm/swappiness)
  echo 100 > /proc/sys/vm/swappiness
  echo 150 > /proc/sys/vm/swappiness 2>/dev/null
  echo 200 > /proc/sys/vm/swappiness 2>/dev/null
  max=$(cat /proc/sys/vm/swappiness)
  echo $current > /proc/sys/vm/swappiness
  echo $max
}

readonly BLK_LINUX='/sys/block/zram0/backing_dev'
BLK_OPLUS='/sys/block/zram0/hybridswap_loop_device'
BLK_MEIZU='/sys/block/zram0/smartswap_loop_device'
readonly WB_LINUX='/sys/block/zram0/writeback'

writeback_supported() {
  if [[ -f $BLK_LINUX && -f $WB_LINUX ]] && [[ $(kernel_compare "4.19") -gt 0 ]]; then
    return_true
  else
    return_false
  fi
}

# 检测是否支持内存拓展
extm_supported() {
  blk=''
  if [[ -f $BLK_OPLUS ]] && [[ $(kernel_compare "6.6") -lt 0 ]]; then
    # ColorOS 6.x内核以后，回写就废了
    blk=$BLK_OPLUS
  elif [[ -f $BLK_MEIZU ]] && [[ $(kernel_compare "6.6") -lt 0 ]]; then
    blk=$BLK_MEIZU
  elif [[ -f $BLK_LINUX && -f $WB_LINUX ]]; then
    blk=$BLK_LINUX
  else
    return_false
  fi

  dev=$(cat $blk)
  if [[ "$dev" == '' || "$dev" == 'chp' || "$dev" == 'none' || "$dev" == *crypto* ]]; then
    return_false
  fi
}

# 判断拓展内存是否已开启
extm_enabled(){
  ext_size=0
  # xiaomi linux
  if [[ -f $WB_LINUX ]] && [[ -f $BLK_LINUX ]]; then
    dev=$(cat $BLK_LINUX)
    if [[ $dev = *loop* ]]; then
      loop_dev=${dev##*/}
      file=$(cat /sys/block/$loop_dev/loop/backing_file)
      ext_size=$(du -b $file | cut -f1)
      # 单位统一为KB
      ext_size=$((ext_size / 1024))
    fi
  else
    # meizu oppo
    for file in smartswap_meminfo hybridswap_meminfo; do
      if [[ -f /sys/block/zram0/$file ]]; then
        ext_size=$(head -1 /sys/block/zram0/$file | tr -s ' ' | cut -d' ' -f2)
        break
      fi
    done
  fi
  # 拓展内存不小于1GB
  if [[ $ext_size -gt 1024000 ]]; then
    return_true
  fi
  return_false
}