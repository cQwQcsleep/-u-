[ ! "$MODPATH" ] && MODPATH=${0%/*}
#get Android version
android_version=$(getprop ro.build.version.release)
alias sh='/system/bin/sh'
a=$(getprop ro.system.build.version.release)
var_device="`getprop ro.product.device`"

print_modname() {
  ui_print "————————————————————————————————————————————————————"
}


set_permissions() {
    set_perm_recursive $MODPATH 0 0 0755 0644
# 设置 /system/vendor/etc 的权限和标签
    set_perm_recursive $MODPATH/system/vendor/etc 0 0 0755 0644 u:object_r:vendor_configs_file:s0
# 设置 /system/vendor/etc/audio 文件夹的权限和标签
    set_perm_recursive $MODPATH/system/vendor/etc/audio 0 0 0755 0644 u:object_r:vendor_configs_file:s0
# 设置 /system/vendor/etc/audio/audio_policy_configuration.xml 文件的权限和标签    
    set_perm $MODPATH/system/vendor/etc/audio/audio_policy_configuration.xml 0 0 0644 u:object_r:vendor_configs_file:s0
# 设置 $MODPATH/system/vendor/lib 目录的权限和标签
    set_perm_recursive $MODPATH/system/vendor/lib 0 0 0755 0755 u:object_r:same_process_hal_file:s0
}

# 【本模块纯参数调音，如需引用调音文件请注明作者】
#sleep 0.4
ui_print "⚠注意⚠：【请仔细查看下面的内容】"
ui_print "————————本模块适用于KSU————————"
sleep 1.0
ui_print "————————————————————————————————————————————————————"
ui_print "本模块仅适用于红米Note12Tubro"
ui_print "————————————————————————————————————————————————————"
sleep 2.0
ui_print "⚠注意⚠：【本模块为纯参数调音，如需引用调音文件请注明作者】"
#sleep 1.5
ui_print "————————————————————————————————————————————————————"
ui_print " 本模块内的overlay参数、Virtual Bass，通路等文件的修改By"
ui_print "-------@NikoRur_QwQRuaa @Huber_HaYu @是Ray酱呀 @Sc素菜 @Hubery_Brook(Gerose)---------"
ui_print "————————————————————————————————————————————————————"
 
policy_configuration() {

ui_print "请问是否引入OpenSL ES输出模式的杜比输出？"
ui_print "————————————————————————————————————————————————————"
ui_print "OpenSL ES模式涉及大部分系统音效，可能出现部分场景扬声器声音过大的问题"
ui_print "可能会导致音量变化时出现爆破音"
ui_print "————————————————————————————————————————————————————"
ui_print "如果不需要(推荐) 请按音量+键 如果需要请按音量-"

key_click=""
    while [ "$key_click" = "" ]; do
        key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
        sleep 0.2
    done
    case "$key_click" in
        "KEY_VOLUMEUP")
        ui_print "已选择 不需要"
        cp -rf $MODPATH/audio $MODPATH/system/vendor/etc/
        sleep 0.5
        ui_print "加载完成"
        ;;
        *)
            ui_print "已选择 需要"
            ui_print "加载完成"
            ui_print "目前该修改可能导致系统部分输出异常，请谨慎对待"            
            ;;
    esac
    
rm -rf $MODPATH/audio
}    

dolby_dax() {

ui_print "————————————————————————————————————————————————————"
ui_print "请问强化有线耳机杜比音量表现?"
ui_print "此修改会导致有线耳机音量大幅度抬高"
ui_print "音量放大可能出现一定电流声"
ui_print "————————————————————————————————————————————————————"
ui_print "选择不需要(推荐) 请按音量+键 选择需要 请按音量-"

key_click=""
    while [ "$key_click" = "" ]; do
        key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
        sleep 0.2
    done
    case "$key_click" in
        "KEY_VOLUMEUP")
        ui_print "已选择 不需要"
        sleep 0.5
        ui_print "加载完成"
        ;;
        *)
            ui_print "已选择 需要"
            cp -rf $MODPATH/dolby $MODPATH/system/vendor/etc/            
            ui_print "加载完成"   
        ;;
    esac
    
rm -rf $MODPATH/dolby
}    

Acoustics_Replace() {

ui_print "————————————————————————————————————————————————————"
ui_print "请问是否需要替换掉新版音质音效"
ui_print "替换旧版音质音效可能会导致关闭杜比后小米音效均衡器无法调用甚至可能会导致音质音效闪退"
ui_print "————————————————————————————————————————————————————"
ui_print "如果需要 请按音量+键 如果不需要请按音量-"
ui_print "————————————————————————————————————————————————————"

key_click=""
    while [ "$key_click" = "" ]; do
        key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
        sleep 0.2
    done
    case "$key_click" in
        "KEY_VOLUMEUP")
        ui_print "已选择 替换新版音质音效"
        ;;
        *)
        ui_print "已选择 不替换新版音质音效"
        rm -rf $MODPATH//system/product
        ;;
    esac
    
ui_print "————————————————————————————————————————————————————"

}

Cache_Clean() {

ui_print "正在清理缓存..."

rm -rf /data/system/package_cache
rm -rf /data/dalvik-cache
rm -rf /data/cache

ui_print "加载完成，重启以体验模块"

}
              
print_modname
set_permissions
policy_configuration
Acoustics_Replace
Cache_Clean